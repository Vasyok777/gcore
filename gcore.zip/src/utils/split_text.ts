export const splitWords = (str: string) => str.split(/\s+/)
