declare module "*.mp4" {
  const value: string
  export default value
}
declare module "*.MP4" {
  const src: string
  export default src
}
