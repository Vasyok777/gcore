const AppLogo = () => {
  return (
    <a href="/" className="logo">
      <img src="/logo.svg" alt="" />
    </a>
  )
}
export default AppLogo
